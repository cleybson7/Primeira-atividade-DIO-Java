package conta;

import java.util.Scanner;

public class ContaTerminal {

 public static void main(String[] args){
  
  int numero;
  double saldo;
  String agencia, nomeCliente;
  
  Scanner scanner = new Scanner(System.in);
   
   System.out.println("----Dados Bancários----\n");
   
   System.out.print("Digite seu nome: ");
   nomeCliente = scanner.nextLine();
   
   System.out.print("\nDigite o nome da agência: ");
   agencia = scanner.nextLine();
   
   System.out.print("\nDigite o número da conta: ");
   numero = scanner.nextInt();
   
   System.out.print("\nDigite o saldo da conta: ");
   saldo = scanner.nextDouble();
   
   System.out.println("\n----Seus dados----\n");
   
   System.out.println("Nome: "+nomeCliente+"\nAgência: "+agencia+"\nNúmero da conta: "+numero+"\nSaldo: "+saldo);
   
 }
}

